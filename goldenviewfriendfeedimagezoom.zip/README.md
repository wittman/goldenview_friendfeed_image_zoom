# Golden View Friendfeed Image Zoom

## General Information

The `friendfeed_image_zoom` userscript / extension for friendfeed.com opens a post image in a new browser tab at full size (not bookmarklet images, only native image uploads).

>_Discussion_: <http://friendfeed.com/fftools/7a677739/friendfeed_image_zoom-browser-extension>

## Change Log

### Version 1.0

- Initial Release